<?php

session_start();

$con=mysqli_connect('localhost','root','R@kshit31');

mysqli_select_db($con,'userregistration');

$name=$_POST['Username'];
$pass=$_POST['password'];
$mob=$_POST['Mobile'];

$s=" select * from usertable where Username = '$name'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	echo"Username already taken";
}
else{
	$reg="insert into usertable(Username,password,Mobile) values ('$name','$pass','$mob')";
	mysqli_query($con,$reg);
	$uname = mysql_real_escape_string($_POST['Username']);
	mysql_query("CREATE TABLE ".$uname." ( id INT(6) AUTO_INCREMENT PRIMARY KEY,image longblob , info_of_img varchar(50)");
	header('location:Login.html');
}



?>