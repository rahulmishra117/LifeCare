Problems:- 

Life is becoming too busy to get medical appointments in person
Maintain a proper health care
Unaware of symptoms and preventions of diseases

Main idea :-

Provide ease and comfort to patients to consult the doctors on video call
Book appointment for physical meeting if needed

Lifecare contains :-

Past health reports of the user 
Alert the user for ongoing diseases that are most active in the environment so user get aware of symptoms and preventions of that disease 

Lifecare suggestions:-

List of the doctors that are available 
Routine checkups remainders

Lifecare facility:-

Delivers medicines at your doorstep
Ease of appointments
